from odoo import models, fields, api

class TelesalesWorkforce(models.Model):
    _name = 'telesales.workforce'
    _description = 'Telesales Workforce Load & Agent Efficiency'

    # ----------------- Load Inputs -------------------
    task_inbound = fields.Integer(string='Inbound Volume')
    inbound_aht = fields.Float(string='Inbound AHT (min)')
    inbound_load = fields.Float(string='Inbound Load (min)', compute='_compute_loads', store=True)

    task_outbound = fields.Integer(string='Outbound Volume')
    outbound_aht = fields.Float(string='Outbound AHT (min)')
    outbound_load = fields.Float(string='Outbound Load (min)', compute='_compute_loads', store=True)

    task_whatsapp = fields.Integer(string='Whatsapp Volume')
    whatsapp_aht = fields.Float(string='Whatsapp AHT (min)')
    whatsapp_concurrency = fields.Integer(string='WhatsApp Concurrency', default=4)
    whatsapp_load = fields.Float(string='Whatsapp Load (min)', compute='_compute_loads', store=True)

    task_confirmation = fields.Integer(string='Confirmation Volume')
    confirmation_aht = fields.Float(string='Confirmation AHT (min)')
    confirmation_load = fields.Float(string='Confirmation Load (min)', compute='_compute_loads', store=True)

    telesales_load = fields.Float(string='Total Telesales Load (min)', compute='_compute_loads', store=True)

    # ----------------- Shrinkage Inputs -------------------
    working_hours = fields.Float(string='Working Hours/Day', default=10.0)
    working_days = fields.Integer(string='Working Days/Week', default=6)
    break_minutes = fields.Integer(string='Break Minutes/Day', default=60)
    annual_vacation = fields.Integer(string='Annual Vacation Days', default=30)
    weekends_per_week = fields.Float(string='Weekend Days/Week', default=1.0)
    actual_agents = fields.Integer(string='Actual Agents')

    # ----------------- Calculated Fields -------------------
    effective_minutes_per_agent = fields.Float(string='Effective Minutes/Agent', compute='_compute_efficiency', store=True)
    total_effective_minutes = fields.Float(string='Total Effective Minutes (All Agents)', compute='_compute_efficiency', store=True)
    daily_effective_minutes = fields.Float(string='Total Daily Effective Minutes', compute='_compute_efficiency', store=True)
    efficiency_pct = fields.Float(string='Efficiency % of Workload Covered', compute='_compute_efficiency', store=True)
    required_agents_to_hire = fields.Float(
        string='Required Agents to Hire',
        compute='_compute_agents_to_hire',
        store=True,
        help="Number of extra agents needed to reach 100% workload coverage"
    )
    daily_effective_agents = fields.Float(
        string='Daily Effective Agents',
        compute='_compute_daily_effective_agents',
        store=True
    )

    # ----------------- Load Calculation -------------------
    @api.depends(
        'task_inbound', 'inbound_aht',
        'task_outbound', 'outbound_aht',
        'task_whatsapp', 'whatsapp_aht', 'whatsapp_concurrency',
        'task_confirmation', 'confirmation_aht'
    )
    def _compute_loads(self):
        for rec in self:
            rec.inbound_load = rec.task_inbound * rec.inbound_aht
            rec.outbound_load = rec.task_outbound * rec.outbound_aht
            rec.whatsapp_load = (rec.task_whatsapp * rec.whatsapp_aht) / rec.whatsapp_concurrency if rec.whatsapp_concurrency else 0.0
            rec.confirmation_load = rec.task_confirmation * rec.confirmation_aht
            rec.telesales_load = (
                rec.inbound_load + rec.outbound_load +
                rec.whatsapp_load + rec.confirmation_load
            )

    # ----------------- Agent Efficiency Calculation -------------------
    @api.depends('working_hours', 'working_days', 'break_minutes', 'annual_vacation', 'actual_agents', 'telesales_load', 'daily_effective_agents')
    def _compute_efficiency(self):
        for rec in self:
            net_daily_minutes = (rec.working_hours * 60) - rec.break_minutes
            rec.effective_minutes_per_agent = net_daily_minutes
            rec.total_effective_minutes = net_daily_minutes * rec.daily_effective_agents
            rec.daily_effective_minutes = rec.total_effective_minutes
            rec.efficiency_pct = (rec.total_effective_minutes / rec.telesales_load * 100) if rec.telesales_load else 0.0

    @api.depends('telesales_load', 'effective_minutes_per_agent', 'total_effective_minutes')
    def _compute_agents_to_hire(self):
        for rec in self:
            if rec.effective_minutes_per_agent and rec.telesales_load > rec.total_effective_minutes:
                rec.required_agents_to_hire = (
                    rec.telesales_load - rec.total_effective_minutes
                ) / rec.effective_minutes_per_agent
            else:
                rec.required_agents_to_hire = 0.0

    # ----------------- Daily Effective Agent Calculation -------------------
    @api.depends('actual_agents', 'annual_vacation', 'working_days', 'weekends_per_week')
    def _compute_daily_effective_agents(self):
        for rec in self:
            if rec.actual_agents and rec.working_days:
                avg_absent_vacation = (rec.actual_agents * rec.annual_vacation) / (52 * rec.working_days)
                avg_absent_weekend = (rec.actual_agents * rec.weekends_per_week) / 7
                rec.daily_effective_agents = rec.actual_agents - avg_absent_vacation - avg_absent_weekend
            else:
                rec.daily_effective_agents = 0.0
