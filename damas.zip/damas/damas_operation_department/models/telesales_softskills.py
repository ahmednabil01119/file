from odoo import models, fields

class TelesalesSoftskills(models.Model):
    _name = 'telesales.soft.skills'
    _description = 'Telesales Soft Skills Evaluation'

    SELECTION_VALUES = [
        ('none', 'None'),
        ('poor', 'Poor'),
        ('fair', 'Fair'),
        ('good', 'Good'),
        ('excellent', 'Excellent')
    ]

    agent_name = fields.Many2one('res.partner',string='Agent Name', required=True)
    date = fields.Date(string='Call Date', default=None)
    customer_phone = fields.Integer(string='Custome Phone', default=None)

    first_impressions = fields.Selection(SELECTION_VALUES, string='First Impression (Greeting)', default='none')
    active_listener = fields.Selection(SELECTION_VALUES, string='Active Listener?', default='none')
    echo_customer_statements = fields.Selection(SELECTION_VALUES, string='Echo Customer Statements?', default='none')
    ask_open_ended = fields.Selection(SELECTION_VALUES, string='Asking Open Ended Questions?', default='none')
    summerizing_customer_needs = fields.Selection(SELECTION_VALUES, string='Summerized Customer Needs?', default='none')
    use_verbal_acknowledgement = fields.Selection(SELECTION_VALUES, string='Use Verbal Acknowledgements?', default='none')
    uses_persuasive_language = fields.Selection(SELECTION_VALUES, string='Use Persuasive Language?', default='none')
    sold_benefits_not_offers = fields.Selection(SELECTION_VALUES, string='Sold Benefits Not Offers?', default='none')
    empathy_statement_used = fields.Selection(SELECTION_VALUES, string='Empathy Statements Used', default='none')
    objections_handling_effective = fields.Selection(SELECTION_VALUES, string='Handled Objections Effectively?', default='none')
    no_robotic_response = fields.Selection(SELECTION_VALUES, string='No Robotic Answers?', default='none')
    recognized_buying_signal = fields.Selection(SELECTION_VALUES, string='Recognized Buying Signals?', default='none')
    move_to_close_effectively = fields.Selection(SELECTION_VALUES, string='Moved to Close Effectively?', default='none')
    transfer_to_survey = fields.Selection(SELECTION_VALUES, string='Transferred To Survey', default='none')
    professional_tone_languages = fields.Selection(SELECTION_VALUES, string='Professional Tone and Language?', default='none')
    rapport_built = fields.Selection(SELECTION_VALUES, string='Rapport Building With Customer?', default='none')
    scripts_adherence = fields.Selection(SELECTION_VALUES, string='Adhered to Script?', default='none')

    call_outcome = fields.Selection([
        ('completed', 'Completed'),
        ('dropped', 'Dropped'),
        ('refused', 'Customer Refused'),
        ('positive', 'Positive Response'),
        ('negative', 'Negative Response'),
        ('neutral', 'Neutral')
    ], string='Call Outcome', default=None)

    scoring_applicable = fields.Boolean(string='Scoring Applicable?', default=True)

    qa_comment = fields.Text(string='Quality Assurance Comment', default=None)
