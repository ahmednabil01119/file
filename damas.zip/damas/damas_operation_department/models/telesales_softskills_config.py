from odoo import models, fields, api

class TelesalesSoftskillsConfiog(models.Model):
    _name = 'telesales.softskills.config'
    _description = 'Telesales Evaluationg Configuration'

    name = fields.Char(string='Evaluation')