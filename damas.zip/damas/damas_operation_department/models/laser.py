import json
import hashlib
import logging
import re
import requests

# If your AI returns Markdown (e.g. you see `**bold**`, `- bullet`), install and uncomment:
# import markdown

from odoo import api, fields, models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class Laser(models.Model):
    _name = 'laser'
    _description = 'Laser Operation'

    #
    # ─── IDENTIFICATION ───────────────────────────────────────────────────────────────
    #
    name = fields.Char(
        string='Machine Name',
        help="Give a descriptive name for this machine setup (e.g., 'Candela Cluster A')."
    )

    #
    # ─── MACHINE SETUP ───────────────────────────────────────────────────────────────
    #
    machine_count = fields.Integer(
        string='Machine Count',
        help="Number of active machines available for reservation in a shift."
    )
    session_duration = fields.Float(
        string='Session Duration (min)',
        default=45.0,
        help="Time (in minutes) required for one session on a single machine."
    )
    machine_working_hours = fields.Float(
        string='Working Hours per Shift',
        default=12.0,
        help="Number of hours each machine operates during its shift."
    )

    total_machine_working_minutes = fields.Float(
        string='Total Machine Working Minutes',
        compute='_compute_totals',
        store=True,
        help="Calculated as: Machine Count × Working Hours × 60. "
             "Represents total minutes of machine availability per shift."
    )

    #
    # ─── RESERVATION (IDEAL) ─────────────────────────────────────────────────────────
    #
    no_show_percent = fields.Float(
        string='Expected No-Show (%)',
        help="Percentage of customers who typically do not show up. Used to calculate how many "
             "bookings are required to achieve full utilization."
    )
    max_arrived_reservations = fields.Float(
        string='Max Arrived Reservations (Ideal)',
        compute='_compute_totals',
        store=True,
        help="Ideal number of sessions (reservations) if machines run continuously with no breaks. "
             "Computed as: Total Machine Working Minutes ÷ Session Duration."
    )
    adjusted_max_reservations = fields.Float(
        string='Reservations to Book (Inc. No-Shows)',
        compute='_compute_totals',
        store=True,
        help="Number of bookings you must accept to achieve full utilization after accounting for no-shows. "
             "Formula: Max Arrived ÷ (1 − No-Show %)."
    )

    #
    # ─── NURSE (IDEAL) ───────────────────────────────────────────────────────────────
    #
    working_days_per_week = fields.Integer(
        string='Working Days/Week',
        default=6,
        help="Number of days a nurse works per week (e.g., 6 = Monday – Saturday)."
    )
    annual_vacation_days = fields.Integer(
        string='Annual Vacation Days',
        default=30,
        help="Total paid vacation days a nurse takes in a year."
    )
    break_minutes_per_day = fields.Float(
        string='Break Minutes per Day',
        default=60.0,
        help="Daily break time (in minutes) deducted from a nurse’s productive hours."
    )
    nurse_daily_working_hours = fields.Float(
        string='Nurse Working Hours per Day',
        default=8.0,
        help="Total hours a nurse is scheduled to work per day (before subtracting breaks)."
    )
    nurse_shrinkage_percent = fields.Float(
        string='Nurse Shrinkage (%)',
        compute='_compute_totals',
        store=True,
        readonly=True,
        help="Percentage of time lost due to vacations. Calculated as: "
             "[(Vacation Days ÷ (Working Days/Week × 52)) × 100]."
    )
    needed_nurses = fields.Float(
        string='Nurses Needed After Shrinkage',
        compute='_compute_totals',
        store=True,
        help="Number of nurses required to cover all machine-minutes. "
             "Computed as: Total Machine Minutes ÷ (Nurse Daily Working Minutes)."
    )

    #
    # ─── ACTUAL PERFORMANCE INPUTS ─────────────────────────────────────────────────
    #
    actual_nurses = fields.Integer(
        string='Actual Nurses On Duty',
        help="Number of nurses actually scheduled/on-duty for this shift."
    )
    actual_reservations = fields.Integer(
        string='Actual Reservations Booked',
        help="Number of reservations actually booked for this shift."
    )

    #
    # ─── PERFORMANCE METRICS (ACTUAL VS. IDEAL) ──────────────────────────────────────
    #
    nurse_utilization_percent = fields.Float(
        string='Nurse Utilization (%)',
        compute='_compute_performance_metrics',
        store=True,
        help="Percentage of required nurse capacity actually deployed. "
             "Formula: (Actual Nurses ÷ Needed Nurses) × 100."
    )
    reservation_utilization_percent = fields.Float(
        string='Reservation Utilization (%)',
        compute='_compute_performance_metrics',
        store=True,
        help="Percentage of ideal reservations actually booked. "
             "Formula: (Actual Reservations ÷ Max Arrived Reservations) × 100."
    )
    nurse_shortage = fields.Float(
        string='Nurse Shortage',
        compute='_compute_performance_metrics',
        store=True,
        help="Difference between required nurses and actual nurses on duty. Computed as: Needed Nurses – Actual Nurses."
    )
    reservation_shortage = fields.Float(
        string='Reservation Shortage',
        compute='_compute_performance_metrics',
        store=True,
        help="Difference between ideal reservations and actual reservations. Computed as: Max Arrived Reservations – Actual Reservations."
    )

    #
    # ─── AI ANALYSIS FIELDS ──────────────────────────────────────────────────────────
    #
    potencial_score = fields.Char(
        string='AI Potential Score',
        readonly=True,
        help="A 1–10 score generated by Deepseek AI, indicating how well current operations "
             "match best-practice utilization."
    )
    ai_justification = fields.Text(
        string='AI Justification',
        readonly=True,
        sanitize=False,
        help="HTML‐formatted analysis and recommendations returned by Deepseek AI."
    )

    #
    # ─── MISSING “last_prompt_hash” FIELD ───────────────────────────────────────────
    #
    last_prompt_hash = fields.Char(
        string='Last AI Prompt Hash',
        readonly=True,
        help="Internal: SHA256 hash of the last prompt inputs. Used to avoid redundant AI calls."
    )

    #
    # ─── COMPUTATION METHODS ─────────────────────────────────────────────────────────
    #
    @api.depends(
        'machine_count', 'machine_working_hours', 'session_duration', 'no_show_percent',
        'working_days_per_week', 'annual_vacation_days', 'break_minutes_per_day', 'nurse_daily_working_hours'
    )
    def _compute_totals(self):
        """
        1) Compute total machine working minutes
        2) Compute ideal (max) arrived reservations
        3) Compute adjusted reservations to book (accounting for no-shows)
        4) Compute nurse shrinkage % and needed nurse count
        """
        for rec in self:
            # ─── Total Machine Working Minutes ─────────────────────────────────
            rec.total_machine_working_minutes = rec.machine_count * rec.machine_working_hours * 60

            # ─── Ideal Reservations (Max Arrived) ──────────────────────────────
            if rec.session_duration:
                rec.max_arrived_reservations = rec.total_machine_working_minutes / rec.session_duration
            else:
                rec.max_arrived_reservations = 0.0

            # ─── Reservations to Book (Including No-Shows) ─────────────────────
            if rec.max_arrived_reservations and rec.no_show_percent:
                rec.adjusted_max_reservations = rec.max_arrived_reservations / (1 - rec.no_show_percent / 100.0)
            else:
                rec.adjusted_max_reservations = rec.max_arrived_reservations or 0.0

            # ─── Nurse Shrinkage & Needed Nurses ───────────────────────────────
            try:
                total_working_days_per_year = rec.working_days_per_week * 52
                actual_working_days = total_working_days_per_year - rec.annual_vacation_days
                # Daily productive minutes per nurse = (Daily working hours × 60) – breaks
                minutes_per_nurse_per_day = (rec.nurse_daily_working_hours * 60) - rec.break_minutes_per_day

                if minutes_per_nurse_per_day > 0:
                    # Nurses needed = total machine-minutes ÷ (minutes per nurse per day)
                    rec.needed_nurses = rec.total_machine_working_minutes / minutes_per_nurse_per_day
                    # Shrinkage % = 100 – (actual working days ÷ total working days) × 100
                    shrinkage = 100 - ((actual_working_days / total_working_days_per_year) * 100)
                    rec.nurse_shrinkage_percent = round(shrinkage, 2)
                else:
                    rec.needed_nurses = 0.0
                    rec.nurse_shrinkage_percent = 0.0
            except (ZeroDivisionError, TypeError):
                rec.needed_nurses = 0.0
                rec.nurse_shrinkage_percent = 0.0

    @api.depends('actual_nurses', 'actual_reservations', 'needed_nurses', 'max_arrived_reservations')
    def _compute_performance_metrics(self):
        """
        Based on actual inputs, compute:
        - Nurse utilization (%)
        - Reservation utilization (%)
        - Nurse shortage
        - Reservation shortage
        """
        for rec in self:
            # ─── Nurse Utilization & Shortage ─────────────────────────────────
            if rec.needed_nurses and rec.actual_nurses is not None:
                rec.nurse_utilization_percent = (rec.actual_nurses / rec.needed_nurses) * 100
            else:
                rec.nurse_utilization_percent = 0.0

            rec.nurse_shortage = (rec.needed_nurses - rec.actual_nurses) if (rec.needed_nurses and rec.actual_nurses is not None) else 0.0

            # ─── Reservation Utilization & Shortage ───────────────────────────
            if rec.max_arrived_reservations and rec.actual_reservations is not None:
                rec.reservation_utilization_percent = (rec.actual_reservations / rec.adjusted_max_reservations) * 100
            else:
                rec.reservation_utilization_percent = 0.0

            rec.reservation_shortage = (rec.adjusted_max_reservations - rec.actual_reservations) if (rec.max_arrived_reservations and rec.actual_reservations is not None) else 0.0

    def action_run_ai_analysis(self):
        """
        Triggered by button click. Gathers all relevant field values, builds a richer prompt
        that explicitly points out when utilization is at or above 100%, and instructs the AI
        to only recommend improvements beyond “fixing” utilization. Uses a 60-second timeout,
        converts line breaks into <br/> for HTML display, and logs each step.
        """
        self.ensure_one()
        _logger.info("==> Starting action_run_ai_analysis for Laser[%s]", self.id)

        # ─── 1) Compute input hash to skip repeats ──────────────────────────────
        inputs = {
            'machine_count': self.machine_count,
            'session_duration': self.session_duration,
            'total_minutes': self.total_machine_working_minutes,
            'no_show_percent': self.no_show_percent,
            'max_arrived': self.max_arrived_reservations,
            'adjusted_book': self.adjusted_max_reservations,
            'actual_reservations': self.actual_reservations,
            'reservation_util_pct': self.reservation_utilization_percent,
            'reservation_shortage': self.reservation_shortage,
            'working_days_per_week': self.working_days_per_week,
            'annual_vacation_days': self.annual_vacation_days,
            'break_minutes_per_day': self.break_minutes_per_day,
            'nurse_daily_working_hours': self.nurse_daily_working_hours,
            'needed_nurses': self.needed_nurses,
            'actual_nurses': self.actual_nurses,
            'nurse_util_pct': self.nurse_utilization_percent,
            'nurse_shortage': self.nurse_shortage,
        }
        prompt_json = json.dumps(inputs, sort_keys=True)
        prompt_hash = hashlib.sha256(prompt_json.encode('utf-8')).hexdigest()
        _logger.debug("Computed prompt_hash: %s", prompt_hash)

        if prompt_hash == (self.last_prompt_hash or ""):
            _logger.info("Inputs unchanged since last run. Skipping AI call.")
            raise UserError(_("AI inputs have not changed since the last run."))
        self.last_prompt_hash = prompt_hash

        # ─── 2) Get API key from System Parameters ──────────────────────────────
        deepseek_key = self.env['ir.config_parameter'].sudo().get_param('deepseek.api_key')
        if not deepseek_key:
            _logger.error("Missing Deepseek API key in system parameters 'deepseek.api_key'.")
            raise UserError(_("Deepseek API key is missing. Please set it in System Parameters."))

        headers = {
            "Authorization": f"Bearer {deepseek_key.strip()}",
            "Content-Type": "application/json"
        }

        # ─── 3) Build a “context-aware” Combined prompt ─────────────────────────
        util_msg = ""
        if self.reservation_utilization_percent >= 100.0 and self.nurse_utilization_percent >= 100.0:
            util_msg = (
                "Note: Both reservation utilization ("
                f"{self.reservation_utilization_percent:.2f}%) and nurse utilization ("
                f"{self.nurse_utilization_percent:.2f}%) are at or above 100%. "
                "This represents an ideal or over-staffed scenario. "
                "Do NOT suggest simply “increase bookings” or “add nurses.”\n"
                "Instead, recommend advanced strategies for maintaining, scaling, or optimizing this level of efficiency."
            )
        elif self.reservation_utilization_percent >= 100.0:
            util_msg = (
                "Note: Reservation utilization is at 100% (no shortage). "
                "Do NOT suggest adding more bookings. "
                "Focus on maintaining throughput, reducing variability, or preparing contingency planning.\n"
            )
        elif self.nurse_utilization_percent >= 100.0:
            util_msg = (
                "Note: Nurse utilization is at 100% or over (no shortage). "
                "Do NOT suggest adding more nurses. "
                "Focus on shift rotation, cross-training, or deeper work-life balance measures.\n"
            )

        combined_prompt = "\n".join([
            "You are a super operations director expert in high-volume, high-efficiency laser clinics.",
            "Below are key metrics. Provide:",
            "  a) A concise evaluation in bullet points (1-2 sentences each).",
            "  b) Two advanced, implementation-level recommendations (include tactics, tools, or processes).",
            "  c) A brief rationale explaining why these recommendations matter given the current context.\n",
            f"Machine Name: {self.name}",
            f"Machine Count: {self.machine_count}",
            f"Session Duration: {self.session_duration:.0f} min",
            f"Working Hours/Shift: {self.machine_working_hours:.0f} hrs",
            f"Total Machine Minutes: {self.total_machine_working_minutes:.0f}\n",
            f"Expected No-Show Rate: {self.no_show_percent:.0f}%",
            f"Ideal (Max Arrived): {self.max_arrived_reservations:.0f} sessions",
            f"Bookings to Accept (inc. no-shows): {self.adjusted_max_reservations:.0f}",
            f"Actual Booked: {self.actual_reservations or 0}",
            f"Reservation Utilization: {self.reservation_utilization_percent:.2f}%",
            f"Reservation Shortage: {self.reservation_shortage:.2f}\n",
            f"Working Days/Week: {self.working_days_per_week}",
            f"Annual Vacation Days: {self.annual_vacation_days}",
            f"Break Minutes/Day: {self.break_minutes_per_day:.0f}",
            f"Nurse Hours/Day: {self.nurse_daily_working_hours:.0f}",
            f"Nurse Shrinkage: {self.nurse_shrinkage_percent:.2f}%",
            f"Nurses Needed: {self.needed_nurses:.2f}",
            f"Actual Nurses: {self.actual_nurses or 0}",
            f"Nurse Utilization: {self.nurse_utilization_percent:.2f}%",
            f"Nurse Shortage: {self.nurse_shortage:.2f}\n",
            util_msg
        ])
        _logger.debug("Combined Prompt:\n%s", combined_prompt)

        try:
            payload = {
                "model": "deepseek-chat",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a super operations director specializing in laser clinic optimization."
                    },
                    {"role": "user", "content": combined_prompt}
                ]
            }

            _logger.info("Sending Combined AI API request (timeout=60s)...")
            response = requests.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers=headers,
                data=json.dumps(payload),
                timeout=60
            )
            _logger.info("Received Response: status_code=%s", response.status_code)

            if response.status_code != 200:
                _logger.error("AI returned error %s: %s", response.status_code, response.text)
                raise UserError(_(
                    "Deepseek call failed (status %s): %s"
                    % (response.status_code, response.text)
                ))

            result = response.json()
            ai_text_raw = result['choices'][0]['message']['content']
            _logger.debug("Raw AI Response:\n%s", ai_text_raw)

            # Convert all newline characters to <br/> for HTML rendering
            ai_text_html = ai_text_raw

            # Extract a 1-10 score if present
            score_match = re.search(r'\b([1-9]|10)\b', ai_text_raw)
            final_score = score_match.group(0) if score_match else "N/A"

            # Write back to fields
            self.potencial_score = final_score
            self.ai_justification = ai_text_html

            _logger.info("AI Analysis complete for Laser[%s]: score=%s", self.id, final_score)

        except requests.Timeout as e:
            _logger.error("AI request timed out after 60s: %s", e)
            raise UserError(_("AI analysis timed out. Please try again in a moment."))
        except Exception as e:
            _logger.exception("Unexpected error during AI call:")
            raise UserError(_("AI analysis failed: %s") % e)

        return True
