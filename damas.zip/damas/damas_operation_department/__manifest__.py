{
    "name": "Damas Department Operation",
    "license": "LGPL-3",
    "depends": ["web"],
    "data": [
        "security/ir.model.access.csv",
        "views/laser.xml",
        "views/telesales.xml",
        "views/telesales_softskills.xml",
        "views/menus.xml",
    ],

}