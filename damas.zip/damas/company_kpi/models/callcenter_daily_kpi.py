from odoo import api, models, fields

class CallCenterDailyKPI(models.Model):
    _name = 'callcenter.daily.kpi'
    _description = 'Call Center Daily KPI'

    # Basic fields
    name = fields.Char(string='Agent Name')
    date = fields.Date(string='Date')
    inbound_calls = fields.Char(string='Inbound')
    outbound_calls = fields.Char(string='Outbound')
    income = fields.Char(string='Income')
    bookings = fields.Char(string='Bookings')
    arrived_rsv = fields.Char(string='Arrived Reservation')
    referrals = fields.Char(string='Referrals')
    bookings_from_whatsapp = fields.Char(string='Booking From Whatsapp')

    # Computed KPI Target Fields
    inbound_target = fields.Float(string='Inbound Target', compute='_compute_kpi_targets_achievements', store=True)
    outbound_target = fields.Float(string='Outbound Target', compute='_compute_kpi_targets_achievements', store=True)
    income_target = fields.Float(string='Income Target', compute='_compute_kpi_targets_achievements', store=True)
    bookings_target = fields.Float(string='Bookings Target', compute='_compute_kpi_targets_achievements', store=True)
    arrived_rsv_target = fields.Float(string='Arrived Reservation Target', compute='_compute_kpi_targets_achievements', store=True)
    referrals_target = fields.Float(string='Referrals Target', compute='_compute_kpi_targets_achievements', store=True)
    bookings_from_whatsapp_target = fields.Float(string='Booking From Whatsapp Target', compute='_compute_kpi_targets_achievements', store=True)

    # Computed KPI Achievement (%) Fields
    inbound_achieved = fields.Float(string='Inbound Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    outbound_achieved = fields.Float(string='Outbound Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    income_achieved = fields.Float(string='Income Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    bookings_achieved = fields.Float(string='Bookings Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    arrived_rsv_achieved = fields.Float(string='Arrived Reservation Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    referrals_achieved = fields.Float(string='Referrals Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)
    bookings_from_whatsapp_achieved = fields.Float(string='Booking From Whatsapp Achievement (%)', compute='_compute_kpi_targets_achievements', store=True)

    # -----------------------------
    # New Overall Performance Field
    # -----------------------------
    final_score = fields.Float(
        string='Overall Performance (%)',
        compute='_compute_overall_performance',
        store=True
    )

    @api.depends(
        'inbound_calls',
        'outbound_calls',
        'income',
        'bookings',
        'arrived_rsv',
        'referrals',
        'bookings_from_whatsapp'
    )
    def _compute_kpi_targets_achievements(self):
        """
        1. Build a map from each KPI name (lowercased) to its target value.
        2. For each record, set <kpi>_target and <kpi>_achieved = (actual/target)*100.
        """
        config_records = self.env['kpi.config'].sudo().search([])
        target_map = {
            rec.name.strip().lower(): float(rec.target or 0)
            for rec in config_records
        }

        for rec in self:
            # Inbound
            inbound_t = target_map.get('inbound', 0.0)
            rec.inbound_target = inbound_t
            rec.inbound_achieved = (
                (float(rec.inbound_calls or 0) / inbound_t) * 100
                if inbound_t else 0.0
            )

            # Outbound
            outbound_t = target_map.get('outbound', 0.0)
            rec.outbound_target = outbound_t
            rec.outbound_achieved = (
                (float(rec.outbound_calls or 0) / outbound_t) * 100
                if outbound_t else 0.0
            )

            # Income
            income_t = target_map.get('income', 0.0)
            rec.income_target = income_t
            rec.income_achieved = (
                (float(rec.income or 0) / income_t) * 100
                if income_t else 0.0
            )

            # Bookings
            bookings_t = target_map.get('bookings', 0.0)
            rec.bookings_target = bookings_t
            rec.bookings_achieved = (
                (float(rec.bookings or 0) / bookings_t) * 100
                if bookings_t else 0.0
            )

            # Arrived Reservation
            arrived_t = target_map.get('arrived reservation', 0.0)
            rec.arrived_rsv_target = arrived_t
            rec.arrived_rsv_achieved = (
                (float(rec.arrived_rsv or 0) / arrived_t) * 100
                if arrived_t else 0.0
            )

            # Referrals
            referrals_t = target_map.get('referrals', 0.0)
            rec.referrals_target = referrals_t
            rec.referrals_achieved = (
                (float(rec.referrals or 0) / referrals_t) * 100
                if referrals_t else 0.0
            )

            # Bookings from WhatsApp
            whatsapp_t = target_map.get('booking from whatsapp', 0.0)
            rec.bookings_from_whatsapp_target = whatsapp_t
            rec.bookings_from_whatsapp_achieved = (
                (float(rec.bookings_from_whatsapp or 0) / whatsapp_t) * 100
                if whatsapp_t else 0.0
            )

    @api.depends(
        'inbound_achieved',
        'outbound_achieved',
        'income_achieved',
        'bookings_achieved',
        'arrived_rsv_achieved',
        'referrals_achieved',
        'bookings_from_whatsapp_achieved'
    )
    def _compute_overall_performance(self):
        """
        Compute final_score as the average of all KPI achievement percentages.
        """
        for rec in self:
            achievements = [
                rec.inbound_achieved,
                rec.outbound_achieved,
                rec.income_achieved,
                rec.bookings_achieved,
                rec.arrived_rsv_achieved,
                rec.referrals_achieved,
                rec.bookings_from_whatsapp_achieved
            ]
            # Count how many KPIs have a target > 0 (to avoid dividing by a KPI with no target)
            valid_count = sum(1 for a in achievements if a is not None)
            if valid_count:
                rec.final_score = sum(achievements) / valid_count
            else:
                rec.final_score = 0.0

    @api.model_create_multi
    def create(self, vals_list):
        final_records = self.env['callcenter.daily.kpi']
        to_create = []

        for vals in vals_list:
            agent_name = vals.get('name')
            agent_date = vals.get('date')
            existing = self.search([
                ('name', '=', agent_name),
                ('date', '=', agent_date),
            ], limit=1)
            if existing:
                existing.write({
                    'inbound_calls': vals.get('inbound_calls'),
                    'outbound_calls': vals.get('outbound_calls'),
                    'income': vals.get('income'),
                    'bookings': vals.get('bookings'),
                    'arrived_rsv': vals.get('arrived_rsv'),
                    'referrals': vals.get('referrals'),
                    'bookings_from_whatsapp': vals.get('bookings_from_whatsapp'),
                })
                final_records |= existing
            else:
                to_create.append(vals)

        if to_create:
            new_records = super(CallCenterDailyKPI, self).create(to_create)
            final_records |= new_records

        return final_records

    @api.model
    def get_top_kpi_agents(self, date_from, date_to):
        domain = [('date', '>=', date_from), ('date', '<=', date_to)]
        records = self.search(domain)

        string_to_field = {
            field_obj.string.strip().lower(): field_name
            for field_name, field_obj in self._fields.items()
            if field_obj.type in ['char', 'float', 'integer']
        }

        result = {}
        config_model = self.env['kpi.config'].sudo()
        for config in config_model.search([('show_on_screen', '=', True)]):
            label = config.name.strip().lower()
            field = string_to_field.get(label)
            if field and field in self._fields:
                sorted_recs = sorted(
                    records,
                    key=lambda r: float(getattr(r, field) or 0),
                    reverse=True
                )
                result[label] = [
                    {'name': r.name, 'value': getattr(r, field)}
                    for r in sorted_recs[:5]
                ]
            else:
                result[label] = []
        return result
