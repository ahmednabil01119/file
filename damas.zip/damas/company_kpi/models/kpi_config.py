from odoo import models, fields

class KPIConfig(models.Model):
    _name = 'kpi.config'
    _description = 'KPI Configuration'

    name = fields.Char(string='KPI Name')
    target = fields.Char(string='Target')
    weight = fields.Char(string='Weight')
    show_on_screen = fields.Boolean(string='Show On Screen')


