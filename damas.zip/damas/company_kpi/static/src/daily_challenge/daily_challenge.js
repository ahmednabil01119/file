/** @odoo-module **/

import { Component, useState, onWillStart, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class DailyDashboard extends Component {
    static template = "company_kpi.DailyChallenge";

    setup() {
        this.orm = useService("orm");
        const today = new Date().toISOString().split("T")[0];

        this.state = useState({
            date_from: today,
            date_to: today,
            polling_interval: 10000,
            kpis: []
        });

        this.previousKpis = [];

        onMounted(() => {
            this.sound = new Audio("/company_kpi/static/src/daily_challenge/win.mp3");
            this.setPolling();
            this.loadStats();
        });

        onWillStart(async () => {
            await this.fetchKPIConfigs();
            await this.loadStats();
        });
    }

    // ✅ Only load KPIs with show_on_screen = true
    async fetchKPIConfigs() {
        try {
            const results = await this.orm.searchRead(
                "kpi.config",
                [["show_on_screen", "=", true]],
                ["name", "target"]
            );

            this.state.kpis = results.map(r => ({
                id: r.id,
                name: r.name,
                target: r.target || "",
                top_agents: []
            }));

            this.previousKpis = results.map(r => ({
                id: r.id,
                name: r.name,
                target: r.target || "",
                top_agents: []
            }));
        } catch (err) {
            console.error("Failed to load KPI Configs:", err);
        }
    }

    async loadStats() {
        const { date_from, date_to } = this.state;
        try {
            const result = await this.orm.call(
                "callcenter.daily.kpi",
                "get_top_kpi_agents",
                [date_from, date_to]
            );

            let anyChanged = false;

            for (let i = 0; i < this.state.kpis.length; i++) {
                const entry = this.state.kpis[i];
                const prevEntry = this.previousKpis[i] || { top_agents: [] };
                const key = (entry.name || "").trim().toLowerCase();
                const newAgents = result[key] || [];

                const prevMap = {};
                for (const prevAgent of (prevEntry.top_agents || [])) {
                    prevMap[prevAgent.name] = prevAgent.value;
                }

                const tagged = newAgents.map(agent => {
                    const oldVal = prevMap[agent.name];
                    const changed =
                        oldVal === undefined ||
                        parseFloat(oldVal) !== parseFloat(agent.value);
                    if (changed) {
                        anyChanged = true;
                    }
                    return {
                        name: agent.name,
                        value: agent.value,
                        changed: changed
                    };
                });

                entry.top_agents = tagged;

                this.previousKpis[i] = {
                    id: entry.id,
                    name: entry.name,
                    target: entry.target,
                    top_agents: newAgents.map(a => ({ name: a.name, value: a.value }))
                };
            }

            if (anyChanged && this.sound) {
                this.sound.play().catch(() => {});
            }
        } catch (err) {
            console.error("Failed to fetch top KPI agents:", err);
        }
    }

    setPolling() {
        if (this.timer) {
            clearInterval(this.timer);
        }
        this.timer = setInterval(() => this.loadStats(), this.state.polling_interval);
    }

    onInputChange(ev) {
        const { name, value } = ev.target;
        this.state[name] = name === "polling_interval" ? parseInt(value, 10) : value;
        this.setPolling();
        this.loadStats();
    }
}

registry.category("actions").add("company_kpi.DailyChallenge", DailyDashboard);
