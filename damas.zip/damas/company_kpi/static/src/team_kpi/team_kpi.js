/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class TeamKPIPage extends Component {
    static template = "custom_dashboards.TeamKPIPage";

    setup() {
        this.orm = useService("orm");

        this.state = useState({
            teamTypes: [],
            selectedTeamType: null,
            teams: [],
            visible: {},
            teamMembers: {},
            memberStats: {},
            teamTotals: {},
            date_from: "",
            date_to: "",
        });

        onWillStart(async () => {
            await this.fetchTeamTypes();
        });
    }

    async fetchTeamTypes() {
        try {
            const types = await this.orm.call("crm.team", "get_unique_team_types", []);
            this.state.teamTypes = types;
        } catch (err) {
            console.error("Failed to fetch team types", err);
        }
    }

    async onSelectTeamType(ev) {
        const typeKey = ev.currentTarget.dataset.key;
        this.state.selectedTeamType = typeKey;
        this.state.visible = {};
        this.state.teams = [];

        try {
            const teams = await this.orm.searchRead("crm.team", [["team_type", "=", typeKey]], ["id", "name"]);
            const visible = {};
            for (const team of teams) {
                visible[team.id] = false;
            }

            this.state.teams = teams;
            this.state.visible = visible;
        } catch (err) {
            console.error("Failed to load teams for type:", typeKey, err);
        }
    }

    toggleVisibility(ev) {
        const teamId = parseInt(ev.currentTarget.dataset.teamId);
        this.state.visible[teamId] = !this.state.visible[teamId];
    }

    async loadTeamMembersAndStats() {
        if (!this.state.date_from || !this.state.date_to) return;

        const result = await this.orm.call(
            "report.custom_dashboards.team_kpi",
            "get_team_kpi_data",
            [this.state.date_from, this.state.date_to]
        );

        this.state.teamMembers = result.teamMembers || {};
        this.state.memberStats = result.memberStats || {};
        this.state.teamTotals = result.teamTotals || {};
    }

    onInputChange(ev) {
        const { name, value } = ev.target;
        this.state[name] = value;

        if (this.state.date_from && this.state.date_to) {
            this.loadTeamMembersAndStats();
        }
    }
}

registry.category("actions").add("custom_dashboards.TeamKPIPage", TeamKPIPage);
