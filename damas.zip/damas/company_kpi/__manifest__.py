{
    "name": "Company KPI's",
    "license": "LGPL-3",
    "depends": ["web"],
    "data": [
        "security/ir.model.access.csv",
        "data/kpi_data.xml",
        "data/kpi_data.xml",

        "views/kpi_config.xml",
        "views/callcenter_daily_kpi.xml",
        "views/data_action_menu.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "company_kpi/static/src/**/*",
            "company_kpi/static/src/daily_challenge/win.mp3",
        ],
    },
    "icon": "custom_dashboards/static/description/icon.png"
}
